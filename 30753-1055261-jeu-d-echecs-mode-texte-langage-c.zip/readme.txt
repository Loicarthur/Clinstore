Jeu d'�checs mode texte (langage c)-----------------------------------
Url     : http://codes-sources.commentcamarche.net/source/30753-jeu-d-echecs-mode-texte-langage-cAuteur  : ChessMentorDate    : 06/09/2013
Licence :
=========

Ce document intitul� � Jeu d'�checs mode texte (langage c) � issu de CommentCaMarche
(codes-sources.commentcamarche.net) est mis � disposition sous les termes de
la licence Creative Commons. Vous pouvez copier, modifier des copies de cette
source, dans les conditions fix�es par la licence, tant que cette note
appara�t clairement.

Description :
=============

Notre projet de jeu d'&eacute;checs en programmation C est termin&eacute;. nous 
avons atteint les 2500 lignes de code (mais nous n'avons pas synth&eacute;tis&ea
cute;s certains coup pour avoir une clart&eacute; dans le code).
<br />Le logic
iel se compose de 9 modules
<br />-initialisation
<br />-affichage
<br />-nou
veaujeu
<br />-droits
<br />-echecsblancs
<br />-echecsnoirs
<br />-chargeme
nt
<br />-sauvegarde
<br />-aide
<br />-option
<br />
<br />Nous avons un j
eu &agrave; deux joueurs, les &eacute;checs sont tous g&eacute;r&eacute;s, les r
oques aussi.
<br />l'&eacute;chec et mat est g&eacute;r&eacute; en partie (l'&e
acute;chec et mat est g&eacute;r&eacute; quand le nombre de mise en &eacute;chec
 est sup&eacute;rieur &agrave; trois)
<br />nous n'avons pas eu le temps de g&e
acute;rer l'&eacute;chec et mat lorsque le roi ne peut pas exercer de d&eacute;p
lacement.
<br />la sauvegarde permet de conserver une partie et d'y revenir. El
le se charge et donne la main &agrave; celui en attente de jouer.
<br />Pour de
s raisons de codes nous avons fait commencer la partie par les pions noirs (enco
re un d&eacute;faut minime).
<br />
<br />La base de cr&eacute;ation nous a &e
acute;t&eacute; inspir&eacute;e par coucou747
<br />Merci &agrave; lui pour nou
s avoir &eacute;vit&eacute; la complication dans notre code ;)
<br /><a name='c
onclusion'></a><h2> Conclusion : </h2>
<br />projet rendu &agrave; l'universit
&eacute; le 29 avril 2005
<br />
<br />version finale disponible
<br />
<br 
/>j'aimerai optimis&eacute; le code en simplifiant l'appellation des pi&egrave;c
es:
<br />passer de Tn(noire) &agrave; t
<br />passe de Tb(blanche) &agrave; T
 ...
<br />et simplifier ainsi les appels des pi&egrave;ces et diminuer le nomb
re de conditions if pour le d&eacute;placement d'une pi&egrave;ce
